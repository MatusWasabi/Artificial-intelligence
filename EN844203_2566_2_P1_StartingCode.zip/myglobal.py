global secret_map
global explore_calls
