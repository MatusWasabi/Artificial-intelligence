#####
#
# Name: TODO
# Student ID: TODO
#
#####

from explore import explore  ##### DO NOT CHANGE THIS LINE #####


def initialize_bfs(m, n, sr, sc, gr, gc):
    pass  # TODO


def bfs():
    pass  # TODO


def initialize_dfs(m, n, sr, sc, gr, gc):
    pass  # TODO


def dfs():
    pass  # TODO


def initialize_Astar(m, n, sr, sc, gr, gc, k):
    pass  # TODO


def Astar():
    return 0  # TODO
